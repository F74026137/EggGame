package project;
import java.awt.event.*;
import javax.swing.*;

public class Action implements ActionListener {
	private int turn;
	
	public void actionPerformed(ActionEvent e){
		
	}

}
