package project;

public interface Game {
	
	public void run();
	public void close();
	public String result();
	public boolean isRunning();

	

}
